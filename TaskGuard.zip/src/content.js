let isGuardActive = false;

// The native browser function to pause tab closure
const guardListener = (e) => {
  if (!isGuardActive) return;
  e.preventDefault();
  e.returnValue = ''; 
};

// Function to inject the visual banner
function createBanner() {
  // Prevent adding multiple banners if clicked twice
  if (document.getElementById('task-guard-banner')) return;

  const banner = document.createElement('div');
  banner.id = 'task-guard-banner';
  banner.innerText = '🛡️ PRIMARY TASK ACTIVE - Mark as completed in the extension before closing.';
  
  // Apply inline CSS to ensure it overrides site styles
  Object.assign(banner.style, {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '100%',
    backgroundColor: '#d32f2f', // Prominent red
    color: '#ffffff',
    textAlign: 'center',
    padding: '8px 15px',
    fontSize: '14px',
    fontWeight: 'bold',
    fontFamily: 'Arial, sans-serif',
    zIndex: '2147483647', // Maximum possible z-index to stay above everything
    boxShadow: '0 4px 6px rgba(0,0,0,0.3)',
    pointerEvents: 'none' // Allows the user to click "through" the banner if it covers a site menu
  });

  document.documentElement.appendChild(banner);
}

// Function to remove the visual banner
function removeBanner() {
  const banner = document.getElementById('task-guard-banner');
  if (banner) {
    banner.remove();
  }
}

// Listen for messages from background.js
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "activate") {
    isGuardActive = true;
    window.addEventListener('beforeunload', guardListener);
    createBanner();
    console.log("Task Guard enabled on this tab.");
  } else if (msg.action === "deactivate") {
    isGuardActive = false;
    window.removeEventListener('beforeunload', guardListener);
    removeBanner();
    console.log("Task Guard disabled. Safe to close.");
  }
});