chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "enableGuard") {
    chrome.scripting.executeScript({
      target: { tabId: msg.tabId },
      files: ["content.js"]
    }).then(() => {
      setTimeout(() => {
        chrome.tabs.sendMessage(msg.tabId, { action: "activate" });
      }, 200);
    }).catch(err => console.error("Injection failed:", err));
  } 
  else if (msg.action === "disableGuard") {
    chrome.tabs.sendMessage(msg.tabId, { action: "deactivate" }).catch(() => {});
  }
});

chrome.runtime.onStartup.addListener(async () => {
  let data = await chrome.storage.local.get(['taskUrl', 'completed', 'type', 'dateSet']);
  
  if (data.taskUrl && data.completed === false) {
    const today = new Date().toDateString();
    
    // Handle expired daily tasks
    if (data.type === 'daily' && data.dateSet !== today) {
      await chrome.storage.local.set({ completed: true });
      chrome.action.setIcon({ path: "icon-completed.svg" });
      return;
    }
    
    // Reopen the pending task
    chrome.tabs.create({ url: data.taskUrl }, (newTab) => {
      chrome.storage.local.set({ taskTabId: newTab.id });
      chrome.runtime.sendMessage({ action: "enableGuard", tabId: newTab.id });
      chrome.action.setIcon({ path: "icon-active.svg" });
      
      // Send Desktop Notification
      chrome.notifications.create('task-guard-reminder', {
        type: 'basic',
        iconUrl: 'icon-active.svg',
        title: 'Task Guard Reminder',
        message: 'Chrome was closed with an uncompleted task. Your task tab has been reopened.',
        priority: 2,
        requireInteraction: true // Keeps the notification on screen until dismissed
      });
    });
  } else {
    chrome.action.setIcon({ path: "icon-completed.svg" });
  }
});