document.addEventListener('DOMContentLoaded', async () => {
  const btnDaily = document.getElementById('btnDaily');
  const btnPerm = document.getElementById('btnPerm');
  const btnComplete = document.getElementById('btnComplete');
  const status = document.getElementById('status');
  const setupView = document.getElementById('setupView');

  // Check current status
  const data = await chrome.storage.local.get(['taskUrl', 'completed', 'type']);
  if (data.taskUrl && !data.completed) {
    setupView.style.display = 'none';
    btnComplete.style.display = 'block';
    status.innerText = `Active ${data.type} task running.`;
  }

  async function setTask(type) {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const taskData = {
      taskTabId: tab.id,
      taskUrl: tab.url,
      type: type,
      dateSet: new Date().toDateString(),
      completed: false
    };
    
    await chrome.storage.local.set(taskData);
    chrome.runtime.sendMessage({ action: "enableGuard", tabId: tab.id });
    
    setupView.style.display = 'none';
    btnComplete.style.display = 'block';
    status.innerText = `Active ${type} task saved!`;
  }

  btnDaily.addEventListener('click', () => setTask('daily'));
  btnPerm.addEventListener('click', () => setTask('permanent'));

  btnComplete.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['taskTabId']);
    await chrome.storage.local.set({ completed: true });
    
    if (data.taskTabId) {
      chrome.runtime.sendMessage({ action: "disableGuard", tabId: data.taskTabId });
    }
    
    btnComplete.style.display = 'none';
    setupView.style.display = 'block';
    status.innerText = "Task completed! Chrome can now close.";
  });
});

document.addEventListener('DOMContentLoaded', async () => {
  const step1 = document.getElementById('step1-type');
  const step2 = document.getElementById('step2-tabs');
  const step3 = document.getElementById('step3-confirm');
  const activeView = document.getElementById('active-view');
  
  const tabListDiv = document.getElementById('tab-list');
  const confirmTypeText = document.getElementById('confirm-type-text');
  const confirmTabTitle = document.getElementById('confirm-tab-title');
  const status = document.getElementById('status');

  let selectedType = '';
  let selectedTab = null;

  // 1. Check if a task is already running when popup opens
  const data = await chrome.storage.local.get(['taskUrl', 'completed', 'type']);
  if (data.taskUrl && !data.completed) {
    activeView.style.display = 'block';
    status.innerText = `Active ${data.type} task running.`;
    chrome.action.setIcon({ path: "icon-active.svg" });
  } else {
    step1.style.display = 'block';
  }

  // --- Step 1: Type Selection ---
  document.getElementById('btnDaily').addEventListener('click', () => loadTabs('daily'));
  document.getElementById('btnPerm').addEventListener('click', () => loadTabs('permanent'));

  async function loadTabs(type) {
    selectedType = type;
    step1.style.display = 'none';
    step2.style.display = 'block';
    tabListDiv.innerHTML = ''; 
    
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    tabs.forEach(tab => {
      const item = document.createElement('div');
      item.className = 'tab-item';
      
      const icon = document.createElement('img');
      icon.className = 'tab-icon';
      icon.src = tab.favIconUrl || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="gray"><rect width="16" height="16" rx="2"/></svg>';
      
      const title = document.createElement('span');
      title.className = 'tab-title';
      title.textContent = tab.title || tab.url;
      
      item.appendChild(icon);
      item.appendChild(title);
      
      item.addEventListener('click', () => showConfirmation(tab));
      tabListDiv.appendChild(item);
    });
  }
  
  document.getElementById('btnBackToType').addEventListener('click', () => {
    step2.style.display = 'none';
    step1.style.display = 'block';
  });

  // --- Step 2 to Step 3: Confirmation ---
  function showConfirmation(tab) {
    selectedTab = tab;
    step2.style.display = 'none';
    step3.style.display = 'block';
    confirmTypeText.textContent = selectedType;
    confirmTabTitle.textContent = tab.title || tab.url;
  }
  
  document.getElementById('btnCancelConfirm').addEventListener('click', () => {
    step3.style.display = 'none';
    step2.style.display = 'block';
  });

  // --- Step 3: Confirm and Inject Guard ---
  document.getElementById('btnConfirm').addEventListener('click', async () => {
    const taskData = {
      taskTabId: selectedTab.id,
      taskUrl: selectedTab.url,
      type: selectedType,
      dateSet: new Date().toDateString(),
      completed: false
    };
    
    await chrome.storage.local.set(taskData);
    chrome.runtime.sendMessage({ action: "enableGuard", tabId: selectedTab.id });
    
    // Change icon to RED
    chrome.action.setIcon({ path: "icon-active.svg" });
    
    step3.style.display = 'none';
    activeView.style.display = 'block';
    status.innerText = `Active ${selectedType} task saved!`;
  });

  // --- Finish Task ---
  document.getElementById('btnComplete').addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['taskTabId']);
    await chrome.storage.local.set({ completed: true });
    
    if (data.taskTabId) {
      chrome.runtime.sendMessage({ action: "disableGuard", tabId: data.taskTabId });
    }
    
    // Change icon to GREEN
    chrome.action.setIcon({ path: "icon-completed.svg" });
    
    activeView.style.display = 'none';
    step1.style.display = 'block';
    status.innerText = "";
  });
});